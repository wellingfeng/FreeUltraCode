import { memo } from 'react';
import { segmentMessage } from './lib/segmenter';
import Markdown from './Markdown';
import ReasoningBlock from './ReasoningBlock';
import CopyButton from './CopyButton';
import ToolCard from './ToolCard';
import type { ToolEvent } from './lib/toolEvent';
import { FileChipBudgetProvider, type OpenFileFn } from './FileChip';
import { answerActionText } from './lib/messageText';
import { type SearchHighlightState } from './lib/searchHighlight';
import { useStore } from '@/store/useStore';
import { t } from '@/lib/i18n';

/** Group tool events into parents + their `parentId` children (one level). */
function nestTools(events: ToolEvent[]): Array<{ event: ToolEvent; children: ToolEvent[] }> {
  const childrenByParent = new Map<string, ToolEvent[]>();
  for (const e of events) {
    if (e.parentId) {
      const list = childrenByParent.get(e.parentId) ?? [];
      list.push(e);
      childrenByParent.set(e.parentId, list);
    }
  }
  return events
    .filter((e) => !e.parentId)
    .map((event) => ({ event, children: childrenByParent.get(event.id) ?? [] }));
}

/**
 * Top-level renderer for one assistant/user/system message's text. Segments the
 * text into ordered reasoning (`<think>…`) and answer chunks, then renders
 * reasoning as collapsible blocks and answers as full markdown (GFM tables,
 * highlighted code, file chips, smart links, KaTeX math, callouts).
 *
 * `streaming` should be true only for the live (last) bubble so an unclosed
 * `<think>` shows as in-progress, partial markdown is repaired, and a trailing
 * typewriter caret follows the last answer. `showActions` adds a hover toolbar
 * with a copy-whole-message button. Memoized on (text, streaming, showActions).
 */
function MessageContentImpl({
  text,
  streaming = false,
  showActions = false,
  onOpenFile,
  cwd,
  searchState = null,
}: {
  text: string;
  streaming?: boolean;
  showActions?: boolean;
  onOpenFile?: OpenFileFn;
  cwd?: string;
  searchState?: SearchHighlightState | null;
}) {
  const locale = useStore((s) => s.locale);
  const segments = segmentMessage(text, streaming);

  if (segments.length === 0) {
    return streaming ? <span className="ai-caret" aria-hidden /> : null;
  }

  // Only the final answer segment is "live"; earlier answers are already sealed
  // by a following reasoning block, so they must not be repaired (which could
  // append a stray backtick to text that legitimately ends in one).
  let lastAnswerIdx = -1;
  for (let i = segments.length - 1; i >= 0; i--) {
    if (segments[i].type === 'answer') {
      lastAnswerIdx = i;
      break;
    }
  }
  // The very last segment overall — a trailing caret goes after it while live.
  const lastIdx = segments.length - 1;

  const copyText = answerActionText(text);

  return (
    <FileChipBudgetProvider>
      <div className="ai-message group/msg relative flex flex-col gap-2">
        {showActions && copyText && (
          <div className="absolute -top-1 right-0 z-10 opacity-0 transition-opacity group-hover/msg:opacity-100">
            <CopyButton
              value={copyText}
              label={t(locale, 'chat.copy')}
              className="rounded border border-border-soft bg-panel-2/80 px-1.5 py-0.5 text-[11px] backdrop-blur"
            />
          </div>
        )}
        {segments.map((seg, i) => {
          if (seg.type === 'reasoning') {
            return (
              <ReasoningBlock
                key={`r${i}`}
                text={seg.text}
                done={seg.done}
                streaming={streaming && !seg.done}
                searchState={searchState}
              />
            );
          }
          if (seg.type === 'tools') {
            return (
              <div key={`t${i}`} className="ai-tools-group flex flex-col">
                {nestTools(seg.events).map(({ event, children }) => (
                  <ToolCard
                    key={event.id}
                    event={event}
                    childrenEvents={children}
                    onOpenFile={onOpenFile}
                    cwd={cwd}
                  />
                ))}
              </div>
            );
          }
          return (
            <div key={`a${i}`} className="ai-answer-sep relative">
              <Markdown
                text={seg.text}
                streaming={streaming && i === lastAnswerIdx}
                onOpenFile={onOpenFile}
                cwd={cwd}
                searchState={searchState}
              />
              {streaming && i === lastIdx && (
                <span className="ai-caret ai-caret--trailing" aria-hidden />
              )}
            </div>
          );
        })}
      </div>
    </FileChipBudgetProvider>
  );
}

const MessageContent = memo(MessageContentImpl);
export default MessageContent;

