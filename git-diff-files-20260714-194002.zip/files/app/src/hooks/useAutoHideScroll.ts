import { useEffect, useRef } from 'react';

/**
 * 给一个滚动容器绑定「自动隐藏滚动条」行为，返回解绑函数。
 * 仅在滚动时、或光标靠近容器右缘（滚动条一侧）时临时显示。
 */
export type AutoHideEdgeSide = 'right' | 'left' | 'both';

export function attachAutoHideScroll(
  el: HTMLElement,
  hideDelay = 900,
  edgeZone = 24,
  edgeSide: AutoHideEdgeSide = 'right',
): () => void {
  let timer: ReturnType<typeof setTimeout> | null = null;
  const showScrolling = () => {
    el.classList.add('is-scrolling');
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => {
      el.classList.remove('is-scrolling');
      timer = null;
    }, hideDelay);
  };

  const onMove = (e: MouseEvent) => {
    const rect = el.getBoundingClientRect();
    const nearRight =
      e.clientX >= rect.right - edgeZone && e.clientX <= rect.right + 2;
    const nearLeft =
      e.clientX <= rect.left + edgeZone && e.clientX >= rect.left - 2;
    const nearEdge =
      edgeSide === 'both'
        ? nearLeft || nearRight
        : edgeSide === 'left'
          ? nearLeft
          : nearRight;
    const insideVertically = e.clientY >= rect.top && e.clientY <= rect.bottom;
    el.classList.toggle('is-edge', nearEdge && insideVertically);
  };
  const onLeave = () => el.classList.remove('is-edge');

  el.addEventListener('scroll', showScrolling, { passive: true });
  el.addEventListener('wheel', showScrolling, { passive: true });
  el.addEventListener('mousemove', onMove, { passive: true });
  el.addEventListener('mouseleave', onLeave, { passive: true });
  return () => {
    if (timer) clearTimeout(timer);
    el.removeEventListener('scroll', showScrolling);
    el.removeEventListener('wheel', showScrolling);
    el.removeEventListener('mousemove', onMove);
    el.removeEventListener('mouseleave', onLeave);
  };
}

/**
 * 滚动条自动隐藏：平时透明。
 * 仅在两种情况下临时显示（CherryStudio 式）：
 *   1) 滚轮滚动 / 内容滚动时；
 *   2) 光标靠近滚动条所在的容器右缘（分割线一侧）时。
 * 配合 .ugs-autohide-scroll（不再用整块 :hover 触发）。
 */
export function useAutoHideScroll<T extends HTMLElement = HTMLDivElement>(
  hideDelay = 900,
  edgeZone = 24,
  edgeSide: AutoHideEdgeSide = 'right',
) {
  const ref = useRef<T | null>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    return attachAutoHideScroll(el, hideDelay, edgeZone, edgeSide);
  }, [hideDelay, edgeZone, edgeSide]);

  return ref;
}
