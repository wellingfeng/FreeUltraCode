使用方式：
1. 在另一台电脑切到同一个仓库、同一个 BASE_COMMIT。
2. 先运行：git apply PATCH.diff
3. 再把 files/ 目录内容覆盖到仓库根目录。
4. 检查：git status

说明：
- files/ 包含当前仍存在的 modified/added/untracked 文件。
- PATCH.diff 包含 tracked 文件的修改、删除、重命名和二进制差异。
- MISSING_OR_DELETED_FILES.txt 记录当前不存在、无法直接打包的路径。
